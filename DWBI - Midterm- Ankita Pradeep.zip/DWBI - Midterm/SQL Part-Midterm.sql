/** Script for SelectTopNRows command from SSMS  **/

-- Question 1--
use pubs;
drop table if exists dim_pubs;
  CREATE TABLE [dbo].[DIM_PUBS](
    [pub_key] int NOT NULL primary key,
	[pub_id] char(4) NOT NULL,
	[pub_name] varchar(40) NULL);


INSERT INTO [dbo].[DIM_PUBS] ([pub_key], [pub_id],pub_name)
SELECT [pub_id] , [pub_id],[pub_name] FROM [dbo].[publishers];


select * from [dbo].[DIM_TITLE] ;

select * from DIM_PUBS;

-- Question 2
DROP TABLE IF EXISTS DIM_DATE;
CREATE TABLE [dbo].[DIM_DATE](
    [date_key] int identity(1,1) NOT NULL primary key,
	[date_str] char(8) NOT NULL,
	[date_year] int NOT NULL,
	[date_month] int NOT NULL,
	[date_qtr] int NOT NULL)
	;


INSERT INTO [dbo].[DIM_DATE] ([date_str],[date_year],[date_month],[date_qtr])
SELECT distinct convert(char(8), ord_date,112) as date_str ,  datepart(year,ord_date) as date_year, datepart(month,ord_date) as date_month,
datepart(quarter,ord_date) as date_qtr
from sales;

select * from dim_date;

--Question 3
drop table if exists dim_title;
CREATE TABLE [dbo].[DIM_TITLE](
	[title_key] int identity(1,1) NOT NULL primary key,
	[title_name] varchar(80) NOT NULL,
	[type_type_id] varchar(10) NOT NULL,
	[title_number] varchar(10) NOT NULL,
	[pub_key] int NULL FOREIGN KEY REFERENCES DIM_PUBS(PUB_KEY)
	)
	;

drop table if exists dim_title_type;
CREATE TABLE [dbo].[DIM_TITLE_TYPE](
    [title_type_key] int identity(1,1) NOT NULL primary key,
	[title_type_id] varchar(10) NOT NULL ,
	[type_name] [char](12) NOT NULL ,
	);

INSERT INTO [dbo].[DIM_TITLE_TYPE]([title_type_id],[type_name])
select distinct substring(title_id, 1, 2) as title_type_id,  [type]  from titles;

select * from DIM_TITLE_TYPE;
select * from dim_title;
